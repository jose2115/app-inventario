<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Traits\Uuids;

class Product extends Model
{
    use HasFactory, Uuids;

    protected $table = 'products';

    protected $fillable = [

        'ref',
        'cod-barra-1',
        'cod-barra-2',
        'cod-barra-3',

        'description',
        'unidad',
        'color',
        'talla',
        'zona_id',
        'unidad1',
        'unidad2',
        'unidad3',


    ];


    public function zona()
    {
        return $this->belongsTo(Zona::class, 'zona_id');
    }
}
