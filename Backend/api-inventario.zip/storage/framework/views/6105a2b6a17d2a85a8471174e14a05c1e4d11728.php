<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\Silice\alqueria\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>